package com.lofou.lofou;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class SK extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sk);
    }

    public void Daftar(View view) {
        Intent Daftar = new Intent(SK.this, Daftar.class);
        startActivity(Daftar);
    }
}
