package com.lofou.lofou;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Daftar extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daftar);
    }

    public void Daftar1(View view) {
        Intent Daftar1 = new Intent(Daftar.this, Daftar1.class);
        startActivity(Daftar1);
    }

    public void SK(View view) {
        Intent SK = new Intent(Daftar.this, SK.class);
        startActivity(SK);
    }
}