package com.lofou.lofou;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Sukses extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sukses);
    }

    public void MainActivity(View view) {
        Intent MainActivity = new Intent(Sukses.this, MainActivity.class);
        startActivity(MainActivity);
    }
}
