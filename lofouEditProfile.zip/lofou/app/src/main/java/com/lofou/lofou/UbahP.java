package com.lofou.lofou;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class UbahP extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ubah_p);
    }

    public void Edit(View view) {
        Intent Edit = new Intent(UbahP.this, Edit.class);
        startActivity(Edit);

    }

    public void Sukses(View view) {
        Intent Sukses = new Intent(UbahP.this, Sukses.class);
        startActivity(Sukses);
    }
}
