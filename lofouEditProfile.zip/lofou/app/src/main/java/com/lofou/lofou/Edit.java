package com.lofou.lofou;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Edit extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);
    }

    public void UbahP(View view) {
        Intent UbahP = new Intent(Edit.this, UbahP.class);
        startActivity(UbahP);
    }

    public void MainActivity(View view) {
        Intent MainActivity = new Intent(Edit.this, MainActivity.class);
        startActivity(MainActivity);

    }

    public void UploadF(View view) {
        Intent UploadF = new Intent(Edit.this, UploadF.class);
        startActivity(UploadF);
    }
}